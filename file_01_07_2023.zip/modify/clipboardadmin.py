from django.contrib import admin
from django.forms.models import modelform_factory
from django.http import JsonResponse
from django.urls import re_path
from django.views.decorators.csrf import csrf_exempt

from .. import settings as filer_settings
from ..models import Clipboard, ClipboardItem, Folder
from ..utils.files import handle_request_files_upload, handle_upload
from ..utils.loader import load_model
from . import views


NO_FOLDER_ERROR = "Can't find folder to upload. Please refresh and try again"
NO_PERMISSIONS_FOR_FOLDER = (
    "Can't use this folder, Permission Denied. Please select another folder."
)


Image = load_model(filer_settings.FILER_IMAGE_MODEL)


# ModelAdmins
class ClipboardItemInline(admin.TabularInline):
    model = ClipboardItem


class ClipboardAdmin(admin.ModelAdmin):
    model = Clipboard
    inlines = [ClipboardItemInline]
    filter_horizontal = ('files',)
    raw_id_fields = ('user',)
    verbose_name = "DEBUG Clipboard"
    verbose_name_plural = "DEBUG Clipboards"

    def get_urls(self):
        return [
            re_path(r'^operations/paste_clipboard_to_folder/$',
                    self.admin_site.admin_view(views.paste_clipboard_to_folder),
                    name='filer-paste_clipboard_to_folder'),
            re_path(r'^operations/discard_clipboard/$',
                    self.admin_site.admin_view(views.discard_clipboard),
                    name='filer-discard_clipboard'),
            re_path(r'^operations/delete_clipboard/$',
                    self.admin_site.admin_view(views.delete_clipboard),
                    name='filer-delete_clipboard'),
            re_path(r'^operations/upload/(?P<folder_id>[0-9]+)/$',
                    ajax_upload,
                    name='filer-ajax_upload'),
            re_path(r'^operations/upload/no_folder/$',
                    ajax_upload,
                    name='filer-ajax_upload'),
        ] + super().get_urls()

    def get_model_perms(self, *args, **kwargs):
        """
        It seems this is only used for the list view. NICE :-)
        """
        return {
            'add': False,
            'change': False,
            'delete': False,
        }


@csrf_exempt
def ajax_upload(request, folder_id=None):
    
    """
    Receives an upload from the uploader. Receives only one file at a time.
    """

    file_path = request.POST['filepath'].split('/') 
    # file_path =  ['todo_test', 'jay', 'test_data_1 (9th copy).pdf']
    # print('file_path: ', file_path)
    file_path = file_path[:-1]
    # print('file_path: ', file_path)

    # if file_path[0] != "undefined":
    #     try:
    #             check_folder = Folder.objects.get(pk=folder_id)
    #             folder_id = check_folder.pk
    #             parent_id  =  check_folder.parent_id
    #             # file_path.pop(0)
    #             # print('file_path.pop(0): ', file_path)
                
                
    #             for folder_name in file_path:
    #                 print('folder_name: ', folder_name)
    #                 if parent_id is None:
    #                     try:
    #                         folder = Folder.objects.get(name=folder_name )
    #                         folder_id = folder.pk
    #                     except:
    #                         folder = Folder.objects.create(name=folder_name, owner_id=request.user.id, parent_id = check_folder.pk)
    #                         folder_id = folder.pk
                            
    #                 parent_id = folder_id
    #                         # try:
    #                             # folder = Folder.objects.get(name=)
    #                         #     pass
    #                         # except:
    #                         #     pass
                        
    #             # for folder_name in file_path:

                

    #         # folder_name = file_path[0]
    #         # print('folder_name: ', folder_name)
    #         # folder = Folder.objects.get(name=folder_name)
    #         # folder_id = folder.pk
    #         # print('folder_id: try ---->', folder_id)


    #     except:
    #         folder = Folder.objects.create(name=file_path[0], owner_id=request.user.id)
    #         folder_id = folder.pk
    #         print('folder_id: except   ---->', folder_id)
    

    parent_id = folder_id
    for folder_name in file_path:
        if parent_id is None:
            try:
                folder = Folder.objects.get(name=folder_name)
                folder_id = folder.pk
            except Folder.DoesNotExist:
                folder = Folder.objects.create(name=folder_name, owner_id=request.user.id, parent_id=parent_id)
                folder_id = folder.pk
        else:
            try:
                folder = Folder.objects.get(name=folder_name, parent_id=parent_id)
                folder_id = folder.pk
            except Folder.DoesNotExist:
                folder = Folder.objects.create(name=folder_name, owner_id=request.user.id, parent_id=parent_id)
                folder_id = folder.pk
        parent_id = folder_id

    print('folder_id:', folder_id)


    if folder_id:
    
        try:
            # Get folder
            folder = Folder.objects.get(pk=folder_id)
            
        except Folder.DoesNotExist:
            return JsonResponse({'error': NO_FOLDER_ERROR})
    else:
        folder = Folder.objects.filter(pk=request.session.get('filer_last_folder_id', 0)).first()

    # check permissions
    if folder and not folder.has_add_children_permission(request):
        return JsonResponse({'error': NO_PERMISSIONS_FOR_FOLDER})

    if len(request.FILES) == 1:
        # dont check if request is ajax or not, just grab the file
        upload, filename, is_raw, mime_type = handle_request_files_upload(request)
    else:
        # else process the request as usual
        upload, filename, is_raw, mime_type = handle_upload(request)
    # TODO: Deprecated/refactor
    # Get clipboad
    # clipboard = Clipboard.objects.get_or_create(user=request.user)[0]

    # find the file type
    for filer_class in filer_settings.FILER_FILE_MODELS:
        FileSubClass = load_model(filer_class)
        # TODO: What if there are more than one that qualify?
        if FileSubClass.matches_file_type(filename, upload, mime_type):
            FileForm = modelform_factory(
                model=FileSubClass,
                fields=('original_filename', 'owner', 'file')
            )
            break
    uploadform = FileForm({'original_filename': filename, 'owner': request.user.pk},
                        {'file': upload})
    uploadform.instance.mime_type = mime_type
    if uploadform.is_valid():
        file_obj = uploadform.save(commit=False)
        # Enforce the FILER_IS_PUBLIC_DEFAULT
        file_obj.is_public = filer_settings.FILER_IS_PUBLIC_DEFAULT
        file_obj.folder = folder
        file_obj.save()
        # TODO: Deprecated/refactor
        # clipboard_item = ClipboardItem(
        #     clipboard=clipboard, file=file_obj)
        # clipboard_item.save()

        thumbnail = None
        data = {
            'thumbnail': thumbnail,
            'alt_text': '',
            'label': str(file_obj),
            'file_id': file_obj.pk,
        }
        # prepare preview thumbnail
        if type(file_obj) == Image:
            thumbnail_180_options = {
                'size': (180, 180),
                'crop': True,
                'upscale': True,
            }
            thumbnail_180 = file_obj.file.get_thumbnail(
                thumbnail_180_options)
            data['thumbnail_180'] = thumbnail_180.url
            data['original_image'] = file_obj.url
        return JsonResponse(data)
    else:
        form_errors = '; '.join(['%s: %s' % (
            field,
            ', '.join(errors)) for field, errors in list(
                uploadform.errors.items())
        ])
        return JsonResponse({'message': str(form_errors)}, status=422)



# @csrf_exempt
# def ajax_upload(request, folder_id=None):
    
#     """
#     Receives an upload from the uploader. Receives only one file at a time.
#     """
#     uploaded_file = request.FILES['file']
#     print('uploaded_file: ', request.POST['filepath'])

#     # Get the file name
#     file_name = uploaded_file.name
#     print('file_name: ', file_name)

#     # Get the file type (MIME type)
#     file_type = uploaded_file.content_type
#     print('file_type: ', file_type)

#     # Get the file's full path on the server
#     file_content = uploaded_file.read()

#     # try:
#     #     file_path = request.POST['filepath'].split('/')
#     #     folder_name = file_path[0]
#     #     folder = Folder.objects.get(name=folder_name)
#     #     folder_id = folder.pk

#     # except:
#     #     folder = Folder.objects.create(name=file_path[0], owner_id=request.user.id)
#     #     folder_id = folder.pk

#     # print("dsfsf")
#     # folder = Folder.objects.create(name="try", owner_id = request.user.id)
#     # folder_id = folder.pk
#     if folder_id:
#         print('folder_id: ', folder_id)
#         try:
#             # Get folder
#             folder = Folder.objects.get(pk=folder_id)
#         except Folder.DoesNotExist:
#             return JsonResponse({'error': NO_FOLDER_ERROR})
#     else:
#         folder = Folder.objects.filter(pk=request.session.get('filer_last_folder_id', 0)).first()

#     # check permissions
#     if folder and not folder.has_add_children_permission(request):
#         return JsonResponse({'error': NO_PERMISSIONS_FOR_FOLDER})

#     if len(request.FILES) == 1:
#         # dont check if request is ajax or not, just grab the file
#         upload, filename, is_raw, mime_type = handle_request_files_upload(request)
#     else:
#         # else process the request as usual
#         upload, filename, is_raw, mime_type = handle_upload(request)
#     # TODO: Deprecated/refactor
#     # Get clipboad
#     # clipboard = Clipboard.objects.get_or_create(user=request.user)[0]

#     # find the file type
#     for filer_class in filer_settings.FILER_FILE_MODELS:
#         FileSubClass = load_model(filer_class)
#         # TODO: What if there are more than one that qualify?
#         if FileSubClass.matches_file_type(filename, upload, mime_type):
#             FileForm = modelform_factory(
#                 model=FileSubClass,
#                 fields=('original_filename', 'owner', 'file')
#             )
#             break
#     uploadform = FileForm({'original_filename': filename, 'owner': request.user.pk},
#                           {'file': upload})
#     uploadform.instance.mime_type = mime_type
#     if uploadform.is_valid():
#         file_obj = uploadform.save(commit=False)
#         # Enforce the FILER_IS_PUBLIC_DEFAULT
#         file_obj.is_public = filer_settings.FILER_IS_PUBLIC_DEFAULT
#         file_obj.folder = folder
#         file_obj.save()
#         # TODO: Deprecated/refactor
#         # clipboard_item = ClipboardItem(
#         #     clipboard=clipboard, file=file_obj)
#         # clipboard_item.save()

#         thumbnail = None
#         data = {
#             'thumbnail': thumbnail,
#             'alt_text': '',
#             'label': str(file_obj),
#             'file_id': file_obj.pk,
#         }
#         # prepare preview thumbnail
#         if type(file_obj) == Image:
#             thumbnail_180_options = {
#                 'size': (180, 180),
#                 'crop': True,
#                 'upscale': True,
#             }
#             thumbnail_180 = file_obj.file.get_thumbnail(
#                 thumbnail_180_options)
#             data['thumbnail_180'] = thumbnail_180.url
#             data['original_image'] = file_obj.url
#         return JsonResponse(data)
#     else:
#         form_errors = '; '.join(['%s: %s' % (
#             field,
#             ', '.join(errors)) for field, errors in list(
#                 uploadform.errors.items())
#         ])
#         return JsonResponse({'message': str(form_errors)}, status=422)


# @csrf_exempt
# def ajax_upload(request, folder_id=None):
    
#     """
#     Receives an upload from the uploader. Receives only one file at a time.
#     """
#     uploaded_file = request.FILES['file']
#     print('uploaded_file: ', request.POST['filepath'])

#     # Get the file name
#     file_name = uploaded_file.name
#     print('file_name: ', file_name)

#     # Get the file type (MIME type)
#     file_type = uploaded_file.content_type
#     print('file_type: ', file_type)

#     # Get the file's full path on the server
#     file_content = uploaded_file.read()

#     # try:
#     #     file_path = request.POST['filepath'].split('/')
#     #     folder_name = file_path[0]
#     #     folder = Folder.objects.get(name=folder_name)
#     #     folder_id = folder.pk

#     # except:
#     #     folder = Folder.objects.create(name=file_path[0], owner_id=request.user.id)
#     #     folder_id = folder.pk

#     # print("dsfsf")
#     # folder = Folder.objects.create(name="try", owner_id = request.user.id)
#     # folder_id = folder.pk
#     if folder_id:
#         print('folder_id: ', folder_id)
#         try:
#             # Get folder
#             folder = Folder.objects.get(pk=folder_id)
#         except Folder.DoesNotExist:
#             return JsonResponse({'error': NO_FOLDER_ERROR})
#     else:
#         folder = Folder.objects.filter(pk=request.session.get('filer_last_folder_id', 0)).first()

#     # check permissions
#     if folder and not folder.has_add_children_permission(request):
#         return JsonResponse({'error': NO_PERMISSIONS_FOR_FOLDER})

#     if len(request.FILES) == 1:
#         # dont check if request is ajax or not, just grab the file
#         upload, filename, is_raw, mime_type = handle_request_files_upload(request)
#     else:
#         # else process the request as usual
#         upload, filename, is_raw, mime_type = handle_upload(request)
#     # TODO: Deprecated/refactor
#     # Get clipboad
#     # clipboard = Clipboard.objects.get_or_create(user=request.user)[0]

#     # find the file type
#     for filer_class in filer_settings.FILER_FILE_MODELS:
#         FileSubClass = load_model(filer_class)
#         # TODO: What if there are more than one that qualify?
#         if FileSubClass.matches_file_type(filename, upload, mime_type):
#             FileForm = modelform_factory(
#                 model=FileSubClass,
#                 fields=('original_filename', 'owner', 'file')
#             )
#             break
#     uploadform = FileForm({'original_filename': filename, 'owner': request.user.pk},
#                           {'file': upload})
#     uploadform.instance.mime_type = mime_type
#     if uploadform.is_valid():
#         file_obj = uploadform.save(commit=False)
#         # Enforce the FILER_IS_PUBLIC_DEFAULT
#         file_obj.is_public = filer_settings.FILER_IS_PUBLIC_DEFAULT
#         file_obj.folder = folder
#         file_obj.save()
#         # TODO: Deprecated/refactor
#         # clipboard_item = ClipboardItem(
#         #     clipboard=clipboard, file=file_obj)
#         # clipboard_item.save()

#         thumbnail = None
#         data = {
#             'thumbnail': thumbnail,
#             'alt_text': '',
#             'label': str(file_obj),
#             'file_id': file_obj.pk,
#         }
#         # prepare preview thumbnail
#         if type(file_obj) == Image:
#             thumbnail_180_options = {
#                 'size': (180, 180),
#                 'crop': True,
#                 'upscale': True,
#             }
#             thumbnail_180 = file_obj.file.get_thumbnail(
#                 thumbnail_180_options)
#             data['thumbnail_180'] = thumbnail_180.url
#             data['original_image'] = file_obj.url
#         return JsonResponse(data)
#     else:
#         form_errors = '; '.join(['%s: %s' % (
#             field,
#             ', '.join(errors)) for field, errors in list(
#                 uploadform.errors.items())
#         ])
#         return JsonResponse({'message': str(form_errors)}, status=422)





# ******************************************************************* 

from django.contrib import admin
from django.forms.models import modelform_factory
from django.http import JsonResponse
from django.urls import re_path
from django.views.decorators.csrf import csrf_exempt

from .. import settings as filer_settings
from ..models import Clipboard, ClipboardItem, Folder
from ..utils.files import handle_request_files_upload, handle_upload
from ..utils.loader import load_model
from . import views


NO_FOLDER_ERROR = "Can't find folder to upload. Please refresh and try again"
NO_PERMISSIONS_FOR_FOLDER = (
    "Can't use this folder, Permission Denied. Please select another folder."
)


Image = load_model(filer_settings.FILER_IMAGE_MODEL)


# ModelAdmins
class ClipboardItemInline(admin.TabularInline):
    model = ClipboardItem


class ClipboardAdmin(admin.ModelAdmin):
    model = Clipboard
    inlines = [ClipboardItemInline]
    filter_horizontal = ('files',)
    raw_id_fields = ('user',)
    verbose_name = "DEBUG Clipboard"
    verbose_name_plural = "DEBUG Clipboards"

    def get_urls(self):
        return [
            re_path(r'^operations/paste_clipboard_to_folder/$',
                    self.admin_site.admin_view(views.paste_clipboard_to_folder),
                    name='filer-paste_clipboard_to_folder'),
            re_path(r'^operations/discard_clipboard/$',
                    self.admin_site.admin_view(views.discard_clipboard),
                    name='filer-discard_clipboard'),
            re_path(r'^operations/delete_clipboard/$',
                    self.admin_site.admin_view(views.delete_clipboard),
                    name='filer-delete_clipboard'),
            re_path(r'^operations/upload/(?P<folder_id>[0-9]+)/$',
                    ajax_upload,
                    name='filer-ajax_upload'),
            re_path(r'^operations/upload/no_folder/$',
                    ajax_upload,
                    name='filer-ajax_upload'),
        ] + super().get_urls()

    def get_model_perms(self, *args, **kwargs):
        """
        It seems this is only used for the list view. NICE :-)
        """
        return {
            'add': False,
            'change': False,
            'delete': False,
        }


@csrf_exempt
def ajax_upload(request, folder_id=None):
    
    """
    Receives an upload from the uploader. Receives only one file at a time.
    """

    file_path = request.POST['filepath'].split('/') 
    print('file_path: ', file_path)
    # file_path =  ['todo_test', 'jay', 'test_data_1 (9th copy).pdf']
    # print('file_path: ', file_path)
    file_path = file_path[:-1]
    # print('file_path: ', file_path)

    # if file_path[0] != "undefined":
    #     try:
    #             check_folder = Folder.objects.get(pk=folder_id)
    #             folder_id = check_folder.pk
    #             parent_id  =  check_folder.parent_id
    #             # file_path.pop(0)
    #             # print('file_path.pop(0): ', file_path)
                
                
    #             for folder_name in file_path:
    #                 print('folder_name: ', folder_name)
    #                 if parent_id is None:
    #                     try:
    #                         folder = Folder.objects.get(name=folder_name )
    #                         folder_id = folder.pk
    #                     except:
    #                         folder = Folder.objects.create(name=folder_name, owner_id=request.user.id, parent_id = check_folder.pk)
    #                         folder_id = folder.pk
                            
    #                 parent_id = folder_id
    #                         # try:
    #                             # folder = Folder.objects.get(name=)
    #                         #     pass
    #                         # except:
    #                         #     pass
                        
    #             # for folder_name in file_path:

                

    #         # folder_name = file_path[0]
    #         # print('folder_name: ', folder_name)
    #         # folder = Folder.objects.get(name=folder_name)
    #         # folder_id = folder.pk
    #         # print('folder_id: try ---->', folder_id)


    #     except:
    #         folder = Folder.objects.create(name=file_path[0], owner_id=request.user.id)
    #         folder_id = folder.pk
    #         print('folder_id: except   ---->', folder_id)
    # ========================================================
    
    # file_path =  ['todo_test', 'jay', 'test_data_1 (9th copy).pdf']
    # parent_id = folder_id
    # for folder_name in file_path:
    #     if parent_id is None:
    #         try:
    #             folder = Folder.objects.get(name=folder_name)
    #             folder_id = folder.pk

    #         except Folder.DoesNotExist:
    #             folder = Folder.objects.create(name=folder_name, owner_id=request.user.id, parent_id=parent_id)
    #             folder_id = folder.pk
    #     else:
    #         try:
    #             folder = Folder.objects.get(name=folder_name, parent_id=parent_id)
    #             folder_id = folder.pk
    #         except Folder.DoesNotExist:
    #             folder = Folder.objects.create(name=folder_name, owner_id=request.user.id, parent_id=parent_id)
    #             folder_id = folder.pk
    #     parent_id = folder_id

    parent_id = folder_id

    for folder_name in file_path:
        if parent_id is None:
            folder = Folder.objects.filter(name=folder_name, parent_id__isnull=True).first()
        else:
            folder = Folder.objects.filter(name=folder_name, parent_id=parent_id).first()

        if folder is None:
            folder = Folder.objects.create(name=folder_name, owner_id=request.user.id, parent_id=parent_id)

        folder_id = folder.pk
        parent_id = folder_id

    print('folder_id:', folder_id)

    # ---------------------



    if folder_id:
    
        try:
            # Get folder
            folder = Folder.objects.get(pk=folder_id)
            
        except Folder.DoesNotExist:
            return JsonResponse({'error': NO_FOLDER_ERROR})
    else:
        folder = Folder.objects.filter(pk=request.session.get('filer_last_folder_id', 0)).first()

    # check permissions
    if folder and not folder.has_add_children_permission(request):
        return JsonResponse({'error': NO_PERMISSIONS_FOR_FOLDER})

    if len(request.FILES) == 1:
        # dont check if request is ajax or not, just grab the file
        upload, filename, is_raw, mime_type = handle_request_files_upload(request)
    else:
        # else process the request as usual
        upload, filename, is_raw, mime_type = handle_upload(request)
    # TODO: Deprecated/refactor
    # Get clipboad
    # clipboard = Clipboard.objects.get_or_create(user=request.user)[0]

    # find the file type
    for filer_class in filer_settings.FILER_FILE_MODELS:
        FileSubClass = load_model(filer_class)
        # TODO: What if there are more than one that qualify?
        if FileSubClass.matches_file_type(filename, upload, mime_type):
            FileForm = modelform_factory(
                model=FileSubClass,
                fields=('original_filename', 'owner', 'file')
            )
            break
    uploadform = FileForm({'original_filename': filename, 'owner': request.user.pk},
                        {'file': upload})
    uploadform.instance.mime_type = mime_type
    if uploadform.is_valid():
        file_obj = uploadform.save(commit=False)
        # Enforce the FILER_IS_PUBLIC_DEFAULT
        file_obj.is_public = filer_settings.FILER_IS_PUBLIC_DEFAULT
        file_obj.folder = folder
        file_obj.save()
        # TODO: Deprecated/refactor
        # clipboard_item = ClipboardItem(
        #     clipboard=clipboard, file=file_obj)
        # clipboard_item.save()

        thumbnail = None
        data = {
            'thumbnail': thumbnail,
            'alt_text': '',
            'label': str(file_obj),
            'file_id': file_obj.pk,
        }
        # prepare preview thumbnail
        if type(file_obj) == Image:
            thumbnail_180_options = {
                'size': (180, 180),
                'crop': True,
                'upscale': True,
            }
            thumbnail_180 = file_obj.file.get_thumbnail(
                thumbnail_180_options)
            data['thumbnail_180'] = thumbnail_180.url
            data['original_image'] = file_obj.url
        return JsonResponse(data)
    else:
        form_errors = '; '.join(['%s: %s' % (
            field,
            ', '.join(errors)) for field, errors in list(
                uploadform.errors.items())
        ])
        return JsonResponse({'message': str(form_errors)}, status=422)



# @csrf_exempt
# def ajax_upload(request, folder_id=None):
    
#     """
#     Receives an upload from the uploader. Receives only one file at a time.
#     """
#     uploaded_file = request.FILES['file']
#     print('uploaded_file: ', request.POST['filepath'])

#     # Get the file name
#     file_name = uploaded_file.name
#     print('file_name: ', file_name)

#     # Get the file type (MIME type)
#     file_type = uploaded_file.content_type
#     print('file_type: ', file_type)

#     # Get the file's full path on the server
#     file_content = uploaded_file.read()

#     # try:
#     #     file_path = request.POST['filepath'].split('/')
#     #     folder_name = file_path[0]
#     #     folder = Folder.objects.get(name=folder_name)
#     #     folder_id = folder.pk

#     # except:
#     #     folder = Folder.objects.create(name=file_path[0], owner_id=request.user.id)
#     #     folder_id = folder.pk

#     # print("dsfsf")
#     # folder = Folder.objects.create(name="try", owner_id = request.user.id)
#     # folder_id = folder.pk
#     if folder_id:
#         print('folder_id: ', folder_id)
#         try:
#             # Get folder
#             folder = Folder.objects.get(pk=folder_id)
#         except Folder.DoesNotExist:
#             return JsonResponse({'error': NO_FOLDER_ERROR})
#     else:
#         folder = Folder.objects.filter(pk=request.session.get('filer_last_folder_id', 0)).first()

#     # check permissions
#     if folder and not folder.has_add_children_permission(request):
#         return JsonResponse({'error': NO_PERMISSIONS_FOR_FOLDER})

#     if len(request.FILES) == 1:
#         # dont check if request is ajax or not, just grab the file
#         upload, filename, is_raw, mime_type = handle_request_files_upload(request)
#     else:
#         # else process the request as usual
#         upload, filename, is_raw, mime_type = handle_upload(request)
#     # TODO: Deprecated/refactor
#     # Get clipboad
#     # clipboard = Clipboard.objects.get_or_create(user=request.user)[0]

#     # find the file type
#     for filer_class in filer_settings.FILER_FILE_MODELS:
#         FileSubClass = load_model(filer_class)
#         # TODO: What if there are more than one that qualify?
#         if FileSubClass.matches_file_type(filename, upload, mime_type):
#             FileForm = modelform_factory(
#                 model=FileSubClass,
#                 fields=('original_filename', 'owner', 'file')
#             )
#             break
#     uploadform = FileForm({'original_filename': filename, 'owner': request.user.pk},
#                           {'file': upload})
#     uploadform.instance.mime_type = mime_type
#     if uploadform.is_valid():
#         file_obj = uploadform.save(commit=False)
#         # Enforce the FILER_IS_PUBLIC_DEFAULT
#         file_obj.is_public = filer_settings.FILER_IS_PUBLIC_DEFAULT
#         file_obj.folder = folder
#         file_obj.save()
#         # TODO: Deprecated/refactor
#         # clipboard_item = ClipboardItem(
#         #     clipboard=clipboard, file=file_obj)
#         # clipboard_item.save()

#         thumbnail = None
#         data = {
#             'thumbnail': thumbnail,
#             'alt_text': '',
#             'label': str(file_obj),
#             'file_id': file_obj.pk,
#         }
#         # prepare preview thumbnail
#         if type(file_obj) == Image:
#             thumbnail_180_options = {
#                 'size': (180, 180),
#                 'crop': True,
#                 'upscale': True,
#             }
#             thumbnail_180 = file_obj.file.get_thumbnail(
#                 thumbnail_180_options)
#             data['thumbnail_180'] = thumbnail_180.url
#             data['original_image'] = file_obj.url
#         return JsonResponse(data)
#     else:
#         form_errors = '; '.join(['%s: %s' % (
#             field,
#             ', '.join(errors)) for field, errors in list(
#                 uploadform.errors.items())
#         ])
#         return JsonResponse({'message': str(form_errors)}, status=422)


# @csrf_exempt
# def ajax_upload(request, folder_id=None):
    
#     """
#     Receives an upload from the uploader. Receives only one file at a time.
#     """
#     uploaded_file = request.FILES['file']
#     print('uploaded_file: ', request.POST['filepath'])

#     # Get the file name
#     file_name = uploaded_file.name
#     print('file_name: ', file_name)

#     # Get the file type (MIME type)
#     file_type = uploaded_file.content_type
#     print('file_type: ', file_type)

#     # Get the file's full path on the server
#     file_content = uploaded_file.read()

#     # try:
#     #     file_path = request.POST['filepath'].split('/')
#     #     folder_name = file_path[0]
#     #     folder = Folder.objects.get(name=folder_name)
#     #     folder_id = folder.pk

#     # except:
#     #     folder = Folder.objects.create(name=file_path[0], owner_id=request.user.id)
#     #     folder_id = folder.pk

#     # print("dsfsf")
#     # folder = Folder.objects.create(name="try", owner_id = request.user.id)
#     # folder_id = folder.pk
#     if folder_id:
#         print('folder_id: ', folder_id)
#         try:
#             # Get folder
#             folder = Folder.objects.get(pk=folder_id)
#         except Folder.DoesNotExist:
#             return JsonResponse({'error': NO_FOLDER_ERROR})
#     else:
#         folder = Folder.objects.filter(pk=request.session.get('filer_last_folder_id', 0)).first()

#     # check permissions
#     if folder and not folder.has_add_children_permission(request):
#         return JsonResponse({'error': NO_PERMISSIONS_FOR_FOLDER})

#     if len(request.FILES) == 1:
#         # dont check if request is ajax or not, just grab the file
#         upload, filename, is_raw, mime_type = handle_request_files_upload(request)
#     else:
#         # else process the request as usual
#         upload, filename, is_raw, mime_type = handle_upload(request)
#     # TODO: Deprecated/refactor
#     # Get clipboad
#     # clipboard = Clipboard.objects.get_or_create(user=request.user)[0]

#     # find the file type
#     for filer_class in filer_settings.FILER_FILE_MODELS:
#         FileSubClass = load_model(filer_class)
#         # TODO: What if there are more than one that qualify?
#         if FileSubClass.matches_file_type(filename, upload, mime_type):
#             FileForm = modelform_factory(
#                 model=FileSubClass,
#                 fields=('original_filename', 'owner', 'file')
#             )
#             break
#     uploadform = FileForm({'original_filename': filename, 'owner': request.user.pk},
#                           {'file': upload})
#     uploadform.instance.mime_type = mime_type
#     if uploadform.is_valid():
#         file_obj = uploadform.save(commit=False)
#         # Enforce the FILER_IS_PUBLIC_DEFAULT
#         file_obj.is_public = filer_settings.FILER_IS_PUBLIC_DEFAULT
#         file_obj.folder = folder
#         file_obj.save()
#         # TODO: Deprecated/refactor
#         # clipboard_item = ClipboardItem(
#         #     clipboard=clipboard, file=file_obj)
#         # clipboard_item.save()

#         thumbnail = None
#         data = {
#             'thumbnail': thumbnail,
#             'alt_text': '',
#             'label': str(file_obj),
#             'file_id': file_obj.pk,
#         }
#         # prepare preview thumbnail
#         if type(file_obj) == Image:
#             thumbnail_180_options = {
#                 'size': (180, 180),
#                 'crop': True,
#                 'upscale': True,
#             }
#             thumbnail_180 = file_obj.file.get_thumbnail(
#                 thumbnail_180_options)
#             data['thumbnail_180'] = thumbnail_180.url
#             data['original_image'] = file_obj.url
#         return JsonResponse(data)
#     else:
#         form_errors = '; '.join(['%s: %s' % (
#             field,
#             ', '.join(errors)) for field, errors in list(
#                 uploadform.errors.items())
#         ])
#         return JsonResponse({'message': str(form_errors)}, status=422)


