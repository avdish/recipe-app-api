class FolderAdmin(PrimitivePermissionAwareModelAdmin):
    list_display = ('name','modified_at')
    exclude = ('parent',)
    list_per_page = 20
    list_filter = ('owner',)
    search_fields = ['name', 'all_files__tag' ]
    autocomplete_fields = ['owner']