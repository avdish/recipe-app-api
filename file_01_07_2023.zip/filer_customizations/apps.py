from django.apps import AppConfig


class FilerCustomizationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'filer_customizations'
    # verbose_name = 'Filer Customizations'
