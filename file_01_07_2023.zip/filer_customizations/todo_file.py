from filer.admin.fileadmin import FileAdmin, FileAdminChangeFrom
from filer.models import File
from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django.conf import settings


class TodoFileAdmin(FileAdmin):
    search_fields = ['name', 'original_filename', 'sha1', 'description', 'tag']

    form = FileAdminChangeFrom
    @classmethod
    def build_fieldsets(cls, extra_main_fields=(), extra_advanced_fields=(),
                        extra_fieldsets=()):
        print('+++++++++++++++++++++++++ todo  build ++++++++++++++++++++++')
        fieldsets = (
            (None, {
                'fields': (
                    'name',
                    'owner',
                    'description',
                    'tag'
                ) + extra_main_fields,
            }),
            (_('Advanced'), {
                'fields': (
                    'file',
                    'sha1',
                    'display_canonical',
                ) + extra_advanced_fields,
                'classes': ('collapse',),
            }),
           
        ) + extra_fieldsets
        if settings.FILER_ENABLE_PERMISSIONS:
            fieldsets = fieldsets + (
                (None, {
                    'fields': ('is_public',)
                }),
            )
        return fieldsets



TodoFileAdmin.fieldsets = TodoFileAdmin.build_fieldsets()
