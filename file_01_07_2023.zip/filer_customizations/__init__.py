# from django.contrib import admin

# from filer.models import Clipboard, File, Folder, FolderPermission, ThumbnailOption
# from filer.settings import FILER_IMAGE_MODEL
# from filer.utils.loader import load_model
# from filer.admin.clipboardadmin import ClipboardAdmin
# from filer.admin.fileadmin import FileAdmin
# from filer.admin.folderadmin import FolderAdmin
# from filer.admin.imageadmin import ImageAdmin
# from filer.admin.permissionadmin import PermissionAdmin
# from filer.admin.thumbnailoptionadmin import ThumbnailOptionAdmin
# from filer.admin.permissions import PrimitivePermissionAwareModelAdmin

# Image = load_model(FILER_IMAGE_MODEL)

# class FolderAdmin(PrimitivePermissionAwareModelAdmin):
#     list_display = ('name',)
#     exclude = ('parent',)
#     list_per_page = 20
#     list_filter = ('owner',)
#     search_fields = ['name']
#     autocomplete_fields = ['owner']
#     save_as = True  # see ImageAdmin
#     actions = ['delete_files_or_folders', 'move_files_and_folders',
#                'copy_files_and_folders', 'resize_images', 'rename_files']

#     directory_listing_template = 'admin/filer/folder/directory_listing.html'
#     order_by_file_fields = ['_file_size', 'original_filename', 'name', 'owner',
#                             'uploaded_at', 'modified_at']

# admin.site.register(Folder, FolderAdmin)
# admin.site.register(File, FileAdmin)
# admin.site.register(Clipboard, ClipboardAdmin)
# admin.site.register(Image, ImageAdmin)
# admin.site.register(FolderPermission, PermissionAdmin)
# admin.site.register(ThumbnailOption, ThumbnailOptionAdmin)
