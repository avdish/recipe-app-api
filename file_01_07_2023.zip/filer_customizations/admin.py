# from django.contrib import admin
# from django.utils.translation import gettext_lazy as _

# from filer.admin.fileadmin import FileAdmin as FilerFileAdmin




# class CustomFileAdmin(FilerFileAdmin):
#     list_display = ('label', 'custom_field')  # Add your custom field(s) here

#     fieldsets = (
#         (None, {
#             'fields': (
#                 'name',
#                 'owner',
#                 'description',
#             ),
#         }),
#         (_('Advanced'), {
#             'fields': (
#                 'file',
#                 'sha1',
#                 'display_canonical',
#             ),
#             'classes': ('collapse',),
#         }),
#     )


# admin.site.unregister(CustomFile)  # Unregister the default File admin
# admin.site.register(CustomFile, CustomFileAdmin)  # Register your custom File admin

# from filer.admin.fileadmin import FileAdmin

# class CustomFileAdmin(FileAdmin):
#     list_display = ['owner_id']


# from django.contrib import admin
# from filer.models import File
# # from .admin import CustomFileAdmin

# admin.site.unregister(File)
# admin.site.register(File, CustomFileAdmin)

# in an admin.py file
# from django.contrib import admin
# from filer.admin import FolderAdmin, ImageAdmin
# from filer.models import Folder, Image, File
# from filer_customizations.models import CustomFile
# # class MyFolderAdmin(FolderAdmin):
# #     owner_search_fields = ['owner_id']

# # admin.site.unregister(Folder)
# # admin.site.register(Folder, FolderAdmin)

# class MyImageAdmin(ImageAdmin):
#     search_fields = ['default_alt_text', 'default_caption', 'author']

# admin.site.unregister(Image)
# admin.site.register(Image, MyImageAdmin)

# from django.contrib import admin
# from filer_customizations.models import CustomFile

# admin.site.unregister(File)
# admin.site.register(CustomFile)

# from f  .permissions import PrimitivePermissionAwareModelAdmin
# from filer.admin.permissions import PrimitivePermissionAwareModelAdmin

# class CustomFileAdmin(PrimitivePermissionAwareModelAdmin):

#     list_display = ["name", "tag"]
#     search_fields = ["tag"]

# admin.site.register(CustomFile, CustomFileAdmin)

# from django.contrib import admin
# from filer.admin import FolderAdmin, FileAdmin, ImageAdmin
# from filer.models import Folder, File, Image
# from django import forms

# class FileAdminChangeFrom(forms.ModelForm):
#     class Meta:
#         model = File
#         fields = '__all__'

#         # exclude = ()


# class MyFileAdmin(FileAdmin):
#     form = FileAdminChangeFrom
#     search_fields = ['image__default_alt_text']

# admin.site.unregister(File)
# admin.site.register(File, MyFileAdmin)

# from django.contrib import admin
# from filer.admin import ImageAdmin
# from filer.models import Image

# class MyImageAdmin(ImageAdmin):
#     search_fields = ['custom_alt_text']


# admin.site.unregister(Image)
# admin.site.register(Image, MyImageAdmin)
# from filer.admin.permissions import PrimitivePermissionAwareModelAdmin
# from django import forms
# from filer.models import Folder, File, Image

# from django.contrib.admin.utils import unquote
# from django.http import HttpResponseRedirect
# from django.urls import reverse
# from django.utils.safestring import mark_safe
# from django.utils.translation import gettext as _

# from filer import settings

# from filer.admin.permissions import PrimitivePermissionAwareModelAdmin
# from filer.admin.tools import AdminContext, admin_url_params_encoded, popup_status

# class FileAdminChangeFrom(forms.ModelForm):
#     class Meta:
#         model = File
#         exclude = ()

# class FileAdmin(PrimitivePermissionAwareModelAdmin):
#     list_display = ('label',)
#     list_per_page = 10
#     search_fields = ['name', 'original_filename', 'sha1', 'description']
#     raw_id_fields = ('owner',)
#     readonly_fields = ('sha1', 'display_canonical')

#     form = FileAdminChangeFrom

#     @classmethod
#     def build_fieldsets(cls, extra_main_fields=(), extra_advanced_fields=(),
#                         extra_fieldsets=()):
#         fieldsets = (
#             (None, {
#                 'fields': (
#                     'name',
#                     'owner',
#                     'description',
#                 ) + extra_main_fields,
#             }),
#             (_('Advanced'), {
#                 'fields': (
#                     'file',
#                     'sha1',
#                     'display_canonical',
#                 ) + extra_advanced_fields,
#                 'classes': ('collapse',),
#             }),
#         ) + extra_fieldsets
#         if settings.FILER_ENABLE_PERMISSIONS:
#             fieldsets = fieldsets + (
#                 (None, {
#                     'fields': ('is_public',)
#                 }),
#             )
#         return fieldsets

#     def response_change(self, request, obj):
#         """
#         Overrides the default to be able to forward to the directory listing
#         instead of the default change_list_view
#         """
#         if (
#             request.POST
#             and '_continue' not in request.POST
#             and '_saveasnew' not in request.POST
#             and '_addanother' not in request.POST
#         ):
#             # Popup in pick mode or normal mode. In both cases we want to go
#             # back to the folder list view after save. And not the useless file
#             # list view.
#             if obj.folder:
#                 url = reverse('admin:filer-directory_listing',
#                               kwargs={'folder_id': obj.folder.id})
#             else:
#                 url = reverse(
#                     'admin:filer-directory_listing-unfiled_images')
#             url = "{0}{1}".format(
#                 url,
#                 admin_url_params_encoded(request),
#             )
#             return HttpResponseRedirect(url)
#         return super().response_change(request, obj)

#     def render_change_form(self, request, context, add=False, change=False,
#                            form_url='', obj=None):
#         info = self.model._meta.app_label, self.model._meta.model_name
#         extra_context = {'show_delete': True,
#                          'history_url': 'admin:%s_%s_history' % info,
#                          'is_popup': popup_status(request),
#                          'filer_admin_context': AdminContext(request)}
#         context.update(extra_context)
#         return super().render_change_form(
#             request=request, context=context, add=add, change=change,
#             form_url=form_url, obj=obj)

#     def delete_view(self, request, object_id, extra_context=None):
#         """
#         Overrides the default to enable redirecting to the directory view after
#         deletion of a image.

#         we need to fetch the object and find out who the parent is
#         before super, because super will delete the object and make it
#         impossible to find out the parent folder to redirect to.
#         """
#         try:
#             obj = self.get_queryset(request).get(pk=unquote(object_id))
#             parent_folder = obj.folder
#         except self.model.DoesNotExist:
#             parent_folder = None

#         if request.POST:
#             # Return to folder listing, since there is no usable file listing.
#             super().delete_view(
#                 request=request, object_id=object_id,
#                 extra_context=extra_context)
#             if parent_folder:
#                 url = reverse('admin:filer-directory_listing',
#                               kwargs={'folder_id': parent_folder.id})
#             else:
#                 url = reverse('admin:filer-directory_listing-unfiled_images')
#             url = "{0}{1}".format(
#                 url,
#                 admin_url_params_encoded(request)
#             )
#             return HttpResponseRedirect(url)

#         return super().delete_view(
#             request=request, object_id=object_id,
#             extra_context=extra_context)

#     def get_model_perms(self, request):
#         """
#         It seems this is only used for the list view. NICE :-)
#         """
#         return {
#             'add': False,
#             'change': False,
#             'delete': False,
#         }

#     def display_canonical(self, instance):
#         canonical = instance.canonical_url
#         if canonical:
#             return mark_safe('<a href="%s">%s</a>' % (canonical, canonical))
#         else:
#             return '-'
#     display_canonical.allow_tags = True
#     display_canonical.short_description = _('canonical URL')


# FileAdmin.fieldsets = FileAdmin.build_fieldsets()



# from django.contrib import admin
from filer.admin import FolderAdmin, FileAdmin, ImageAdmin
# from filer.models import Folder, File, Image
# from django import forms


# class MyFileAdmin(FileAdmin):
#     search_fields = ['mime_type']

# admin.site.unregister(File)
# admin.site.register(File, MyFileAdmin)

# from filer import settings as filer_settings
# from filer import views
# from filer import urls

# from filer.admin import FolderAdmin
# from filer.models import Folder
# from django import forms

# class MyFileAdmin(FileAdmin):
#     search_fields = ['mime_type']

# in an admin.py file
from django.contrib import admin
from filer.admin import FolderAdmin, FileAdmin
from filer.models import Folder, File, Image 
from filer import settings
from django.contrib.auth.models import User

# class MyFileAdmin(FileAdmin):
#     search_fields = ['mime_type']

# admin.site.unregister(File)
# admin.site.register(File, MyFileAdmin)

# class MyFolderAdmin(FolderAdmin):
#     owner_search_fields = ['owner__']

# admin.site.unregister(Folder)
# admin.site.register(Folder, MyFolderAdmin)

# class MyFolderAdmin(FolderAdmin):
#     owner_search_fields = []

# admin.site.unregister(Folder)
# admin.site.register(Folder, MyFolderAdmin)

from filer_customizations.todo_file import TodoFileAdmin
from filer.models import Folder, File, Image 
admin.site.unregister(File)  # Unregister the default FileAdmin
admin.site.register(File, TodoFileAdmin)  # Register your subclass
