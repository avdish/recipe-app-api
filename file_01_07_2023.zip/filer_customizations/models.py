# from django.db import models

# # Create your models here.
# from filer.models import File

# class CustomFile(File):
#     tag = models.CharField(max_length=255, blank=True)

    # class Meta:
    #     proxy = Tru

from django.contrib.auth.models import User