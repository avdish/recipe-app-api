from grappelli.dashboard import Dashboard

class CustomIndexDashboard(Dashboard):
    def init_with_context(self, context):
        self.title = '<img src="/static/th.svg" alt="Logo"> Bisag---n'
