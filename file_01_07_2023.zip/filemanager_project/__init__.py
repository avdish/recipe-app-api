
# from django.contrib import admin
# from filer.admin import ImageAdmin
# from filer.models import Image

# class MyImageAdmin(ImageAdmin):
#     search_fields = ['custom_alt_text']


# admin.site.unregister(Image)
# admin.site.register(Image, MyImageAdmin)
# print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")